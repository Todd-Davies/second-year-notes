#!/bin/bash
rm *.log
rm *.out
rm *.aux
rm *.toc
rm *.tex.bak
